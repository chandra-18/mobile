import * as React from 'react';
import { Text, ListItem, Image } from 'react-native-elements';
import { View } from 'react-native';
import { Avatar } from 'react-native-elements';
import { MaterialCommunityIcons } from '@expo/vector-icons';

function Item(item) {
  let [isFavorite, setFavorite] = React.useState(false);

  return (
    <View
      style={{
        backgroundColor: '#fff',
        margin: 5,
        maxWidth: 150,
        display: 'flex',
        borderRadius: 20,
      }}>
      <View
        style={{
          display: 'flex',
          flexDirection: 'row',
          alignItems: 'center',
          margin: 10,
        }}>
        <Avatar
          size={30}
          source={{
            uri: item.author.profileUrl,
          }}
          imageProps={{ containerStyle: { borderRadius: 10 } }}
        />
        <Text style={{ paddingLeft: 10, fontWeight: 500, fontSize: 12 }}>
          {item.author.name}
        </Text>
      </View>
      <View style={{ position: 'relative' }}>
        <Image
          source={{ uri: item.imageUrl }}
          style={{
            width: 150,
            height: 150,
            borderRadius: 20,
            marginBottom: 15,
          }}
        />
        <MaterialCommunityIcons
          name={isFavorite ? 'heart' : 'heart-outline'}
          size={20}
          style={{
            position: 'absolute',
            top: 15,
            right: 15,
            cursor: 'pointer',
            color: '#FFFFFF',
            border: '1px solid transparent',
          }}
          onPress={() => setFavorite(!isFavorite)}
        />
      </View>
      <Text style={{ fontWeight: 700, fontSize: 17 }}>{item.receipeName}</Text>
      <View
        style={{
          alignItems: 'start',
          display: 'flex',
          flexDirection: 'row',
          color: '#9FA5C0',
          fontSize: 12,
          fontWeight: 600,
        }}>
        <Text style={{ marginRight: 5, color: 'inherit' }}>
          {item.category}
        </Text>
        <MaterialCommunityIcons
          name="circle-small"
          size={20}
          style={{ color: 'inherit' }}
        />
        <Text style={{ color: 'inherit' }}>{item.cookingDuration} mins</Text>
      </View>
    </View>
  );
}

export default Item;
