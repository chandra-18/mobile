import * as React from 'react';
import { Text, View, ScrollView, StatusBar, StyleSheet } from 'react-native';
import Users from './users';
import categories from '../../demoData/Categories.json';
import Item from './item';

function Home(props) {
  let categoryList = ['All', ...categories];
  const [selectedCategory, setSelectedCategory] = React.useState('All');
  const [items, setItems] = React.useState(props.items);

  const filterItems = (category) => {
    setSelectedCategory(category);
    if (category === 'All') setItems(props.items);
    else
      setItems(
        props.items.filter((_itemData) => _itemData.category === category)
      );
  };

  return (
    <View
      style={{
        width: '100%',
        padding: 10,
        paddingRight: 0,
        backgroundColor: '#fff',
      }}>
      <Users />
      <Text
        style={{
          fontWeight: 700,
          fontSize: 17,
          color: '#3E5481',
          marginBottom: 10,
        }}>
        Category
      </Text>
      <View style={{ display: 'flex', flexDirection: 'row' }}>
        <ScrollView horizontal showsHorizontalScrollIndicator={false}>
          {categoryList.map((_category) => (
            <Text
              style={{
                fontWeight: 700,
                fontSize: 15,
                borderRadius: 50,
                border: '1px solid transparent',
                width: 'fit-content',
                padding: 10,
                paddingLeft: 25,
                paddingRight: 25,
                cursor: 'pointer',
                margin: 5,
                backgroundColor:
                  selectedCategory === _category ? '#fef295' : '#F4F5F7',
                color: selectedCategory === _category ? 'inherit' : '#9FA5C0',
              }}
              onPress={() => filterItems(_category)}>
              {_category}
            </Text>
          ))}
        </ScrollView>
      </View>
      <ScrollView showsVerticalScrollIndicator={false}>
        <View
          style={{
            height: '73vh',
            display: 'flex',
            flexDirection: 'row',
            flexWrap: 'wrap',
          }}>
          {items.map((_item, index) => (
            <Item key={index} {..._item} />
          ))}
        </View>
      </ScrollView>
    </View>
  );
}

export default Home;
