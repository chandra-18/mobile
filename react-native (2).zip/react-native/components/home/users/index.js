import * as React from 'react';
import { ScrollView, Text, View } from 'react-native';
import { Avatar } from 'react-native-elements';
import usersData from '../../../demoData/Users.json';

const imagepath = '../../../images/users';

function Users() {
  return (
    <ScrollView horizontal={true} showsHorizontalScrollIndicator={false}>
      <View
        style={{
          flexDirection: 'row',
          padding: 10,
          paddingLeft: 5,
          paddingRight: 5,
        }}>
        <Avatar
          size={56}
          rounded
          containerStyle={{ border: '2px solid #FFF395', marginRight: 7 }}
          source={{
            uri:
              'https://res.cloudinary.com/doaapaamj/image/upload/v1627995597/Avatar_1_vk5e1v.png',
          }}
          styles={{ margin: 20 }}>
          <Avatar.Accessory
            name="add"
            type="Ionicons"
            size={25}
            styles={{ backgroundColor: 'white' }}
          />
        </Avatar>
        {usersData.map((_user) => (
          <Avatar
            key={_user.id}
            size={56}
            containerStyle={{ border: '2px solid #FFF395', marginRight: 7 }}
            rounded
            source={{
              // uri: imagepath + _user.profileUrl,
              uri: _user.profileUrl,
            }}></Avatar>
        ))}
      </View>
    </ScrollView>
  );
}

export default Users;
