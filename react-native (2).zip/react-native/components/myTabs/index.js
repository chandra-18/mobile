import React, { useState } from 'react';
import { Text, View } from 'react-native';
import { NavigationContainer } from '@react-navigation/native';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import Home from '../home';
import Profile from '../profile';
import Notifications from '../notifications';
import Post from '../post';
import itemsData from '../../demoData/Items.json';

const Tab = createBottomTabNavigator();

function MyTabs() {
  const [selectedTab, setSelectedTab] = useState('Home');
  const [items, setItems] = useState(itemsData);
  return (
    <Tab.Navigator
      initialRouteName={selectedTab}
      tabBarOptions={{
        activeTintColor: '#fef295',
      }}>
      <Tab.Screen
        name="Home"
        component={() => <Home items={items} />}
        options={{
          tabBarLabel: () => <Text style={{ fontWeight: 500 }}>Home</Text>,
          tabBarIcon: ({ color, size }) => (
            <MaterialCommunityIcons name="home" color={color} size={size} />
          ),
        }}
      />
      <Tab.Screen
        name="Post"
        component={({ navigation }) => (
          <Post
            items={items}
            updateItems={(updatedItems) => setItems(updatedItems)}
            navigateHome={() => navigation.navigate('Home')}
          />
        )}
        options={{
          tabBarLabel: () => <Text style={{ fontWeight: 500 }}>Post</Text>,
          tabBarIcon: ({ color, size }) => (
            <MaterialCommunityIcons
              name="pen-minus"
              color={color}
              size={size}
            />
          ),
        }}
      />

      <Tab.Screen
        name="Search"
        component={Notifications}
        options={{
          tabBarLabel: () => <Text style={{ fontWeight: 500 }}>Search</Text>,
          tabBarIcon: ({ color, size }) => (
            <MaterialCommunityIcons
              name="magnify"
              color={color}
              size={size}
              style={{
                position: 'absolute',
                bottom: 10,
                border: '1px solid #fef295',
                padding: 10,
                borderRadius: '50%',
                backgroundColor: '#fef295',
              }}
            />
          ),
        }}
      />
      <Tab.Screen
        name="Notifications"
        component={Notifications}
        options={{
          tabBarLabel: () => (
            <Text style={{ fontWeight: 500 }}>Notifications</Text>
          ),
          tabBarIcon: ({ color, size }) => (
            <MaterialCommunityIcons name="bell" color={color} size={size} />
          ),
        }}
      />
      <Tab.Screen
        name="Profile"
        component={Profile}
        options={{
          tabBarLabel: () => <Text style={{ fontWeight: 500 }}>Profile</Text>,
          tabBarIcon: ({ color, size }) => (
            <MaterialCommunityIcons name="account" color={color} size={size} />
          ),
        }}
      />
    </Tab.Navigator>
  );
}

export default MyTabs;
