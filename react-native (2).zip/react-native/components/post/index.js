import React, { useState, useEffect } from 'react';
import { Text, TextInput, View, Image, Picker,TouchableOpacity,StyleSheet } from 'react-native';
import Slider from '@react-native-community/slider';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import Categories from '../../demoData/Categories.json';
import Users from '../../demoData/Users.json';
import Items from '../../demoData/Items.json';
import { Camera } from 'expo-camera';


function Page1(props) {
  const [text, setText] = useState('');
  const [description, setDescription] = useState('');
  const [duration, setDuration] = useState(30);
  const durationsLimits = [
    {
      key: 0,
      value: '<10',
    },
    {
      key: 30,
      value: '30',
    },
    {
      key: 60,
      value: '>60',
    },
  ];
  const [hasPermission, setHasPermission] = useState(null);
  const [type, setType] = useState(Camera.Constants.Type.back);

  useEffect(() => {
    (async () => {
      const { status } = await Camera.requestPermissionsAsync();
      setHasPermission(status === 'granted');
    })();
  }, []);

  if (hasPermission === null) {
    return <View />;
  }
  if (hasPermission === false) {
    return <Text>No access to camera</Text>;
  }
  const openCam=()=>{
    return(
      <View style={styles.container}>
      <Camera style={styles.camera} type={type}>
        <View style={styles.buttonContainer}>
          <TouchableOpacity
            style={styles.button}
            onPress={() => {
              setType(
                type === Camera.Constants.Type.back
                  ? Camera.Constants.Type.front
                  : Camera.Constants.Type.back
              );
            }}>
            <Text style={styles.text}> Flip </Text>
          </TouchableOpacity>
        </View>
      </Camera>
    </View>
    )
  }
  return (
    <View style={{ height: '100vh' }}>
      <View style={{ padding: 20 }}>
      <TouchableOpacity onPress={()=>{openCam()}}>
        <View
          style={{
            borderWidth: 2,
            borderStyle: 'dashed',
            borderColor: '#D0DBEA',
            borderRadius: 16,
            justifyContent: 'center',
            alignItems: 'center',
            padding: 20,
            marginBottom: 20,
          }}>
          <Image
            source={require('../../images/imagePlaceholder.png')}
            width={53}
            height={53}
            style={{ marginBottom: 10 }}
          />
          <Text
            style={{
              fontWeight: 'bold',
              fontSize: 15,
              textAlign: 'center',
              marginBottom: 10,
            }}>
            Add Cover Photo
          </Text>
          <Text
            style={{
              fontWeight: 500,
              textAlign: 'center',
              color: '#9FA5C0',
            }}>
            (up to 12Mb)
          </Text>
        </View>
        </TouchableOpacity>
        <View style={{ marginBottom: 25 }}>
          <Text
            style={{
              fontWeight: 'bold',
              color: 'inherit',
              marginBottom: 15,
            }}>
            Recipe Name
          </Text>
          <TextInput
            style={{
              border: '1px solid #3E5481',
              boxSizing: 'border-box',
              borderRadius: 32,
              padding: 10,
              paddingLeft: 15,
              fontWeight: 600,
              outline: 'none',
            }}
            placeholder="Enter recipe name"
            onChangeText={(text) => setText(text)}
            defaultValue={text}
          />
        </View>
        <View style={{ marginBottom: 25 }}>
          <Text
            style={{
              fontWeight: 'bold',
              color: 'inherit',
              marginBottom: 15,
            }}>
            Description
          </Text>
          <TextInput
            multiline
            numberOfLines={5}
            style={{
              border: '1px solid #3E5481',
              boxSizing: 'border-box',
              borderRadius: 10,
              padding: 10,
              fontWeight: 600,
              outline: 'none',
            }}
            placeholder="Tell the community a little about your recipe"
            onChangeText={(text) => setDescription(text)}
            defaultValue={description}
          />
        </View>
        <View style={{ marginBottom: 25 }}>
          <Text
            style={{
              fontWeight: 'bold',
              color: 'inherit',
              marginBottom: 15,
            }}>
            Cooking Duration
          </Text>
          <View
            style={{
              display: 'flex',
              flexDirection: 'row',
              columnGap: 115,
              marginBottom: 15,
            }}>
            {durationsLimits.map((_durationLimit) => (
              <Text
                key={_durationLimit.key}
                style={{
                  fontWeight: 600,
                  color: _durationLimit.key <= duration ? '#FFF395' : 'inherit',
                }}>
                {_durationLimit.value}
              </Text>
            ))}
          </View>
          <Slider
            maximumValue={60}
            minimumValue={0}
            thumbTintColor="#FFF395"
            minimumTrackTintColor="#FFF395"
            maximumTrackTintColor="lightgray"
            step={30}
            value={duration}
            onValueChange={(sliderValue) => setDuration(sliderValue)}
          />
        </View>
        <TouchableOpacity
          onPress={() => props.nextPage(text, description, duration)}>
        <Text
          style={{
            fontWeight: 'bold',
            fontSize: 20,
            textAlign: 'center',
            backgroundColor: '#FFF395',
            padding: 10,
            margin: 20,
            borderRadius: 32,
            cursor: 'pointer',
            border: `1px solid transparent`,
          }}
          >
          {`Next`}
        </Text>
        </TouchableOpacity>
      </View>
    </View>
  );
}

function Page2(props) {
  const [category, setCategory] = useState(Categories[0]);
  const [user, setUser] = useState(Users[0]);

  return (
    <View style={{ height: '100vh', padding: 20 }}>
      <View style={{ marginBottom: 30 }}>
        <Text
          style={{
            fontWeight: 'bold',
            color: 'inherit',
            marginBottom: 15,
          }}>
          Category
        </Text>
        <Picker
          style={{
            border: '1px solid #3E5481',
            boxSizing: 'border-box',
            borderRadius: 10,
            padding: 10,
            fontWeight: 600,
            outline: 'none',
          }}
          selectedValue={category}
          onValueChange={(itemValue, itemIndex) => setCategory(itemValue)}>
          {Categories.map((_category) => (
            <Picker.Item label={_category} value={_category} />
          ))}
        </Picker>
      </View>
      <View style={{ marginBottom: 30 }}>
        <Text
          style={{
            fontWeight: 'bold',
            color: 'inherit',
            marginBottom: 15,
          }}>
          User
        </Text>
        <Picker
          style={{
            border: '1px solid #3E5481',
            boxSizing: 'border-box',
            borderRadius: 10,
            padding: 10,
            fontWeight: 600,
            outline: 'none',
          }}
          selectedValue={user.name}
          onValueChange={(itemValue, itemIndex) => setUser(Users[itemIndex])}>
          {Users.map((_user) => (
            <Picker.Item label={_user.name} value={_user.name} />
          ))}
        </Picker>
      </View>
      <View style={{ display: 'flex', flexDirection: 'row' }}>
      <TouchableOpacity onPress={()=>props.prevPage()}>
        <Text
          style={{
            fontWeight: 'bold',
            fontSize: 20,
            textAlign: 'center',
            backgroundColor: '#9FA5C0',
            padding: 10,
            color: '#fff',
            margin: 20,
            width: 100,
            borderRadius: 32,
            cursor: 'pointer',
            border: `1px solid transparent`,
          }}>
          {`Back`}
        </Text>
        </TouchableOpacity>
        <TouchableOpacity onPress={()=>props.saveItem(category,user)}>
        <Text
          style={{
            fontWeight: 'bold',
            fontSize: 20,
            textAlign: 'center',
            backgroundColor: '#FFF395',
            padding: 10,
            margin: 20,
            width: 100,
            borderRadius: 32,
            cursor: 'pointer',
            border: `1px solid transparent`,
          }}>
          {`Save`}
        </Text>
        </TouchableOpacity>
      </View>
    </View>
  );
}

function Post(props) {
  const [selectedPage, setSelectedPage] = useState(1);
  const [state, setState] = useState();

  useEffect(() => {
    setSelectedPage(1);
  }, []);

  return (
    <View
      style={{
        backgroundColor: '#fff',
        color: '#3E5481',
        position: 'relative',
      }}>
      <View
        style={{
          display: 'flex',
          flexDirection: 'row',
          justifyContent: 'space-between',
          margin: 10,
        }}>
        <TouchableOpacity onPress={props.navigateHome}>
        <Text
          style={{
            fontWeight: 'bold',
            fontSize: 17,
            color: '#FF6464',
            cursor: 'pointer',
          }}>
          Cancel
        </Text>
        </TouchableOpacity>
        <Text
          style={{
            fontWeight: 'bold',
            fontSize: 17,
            textAlign: 'center',
            color: '#3E5481',
          }}>
          {selectedPage}/2
        </Text>
      </View>
      {selectedPage == 1 ? (
        <Page1
          nextPage={(_name, _description, _duration) => {
            setState({
              ...state,
              receipeName: _name,
              description: _description,
              cookingDuration: _duration,
            });
            setSelectedPage(2);
          }}
        />
      ) : (
        <View>
          <Page2
            prevPage={() => setSelectedPage(1)}
            saveItem={(_category, _user) => {
              setSelectedPage(1);
              props.updateItems([
                ...props.items,
                { ...state, category: _category, author: _user },
              ]);
              props.navigateHome();
            }}
          />
        </View>
      )}
    </View>
  );
}
const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  camera: {
    flex: 1,
  },
  buttonContainer: {
    flex: 1,
    backgroundColor: 'transparent',
    flexDirection: 'row',
    margin: 20,
  },
  button: {
    flex: 0.1,
    alignSelf: 'flex-end',
    alignItems: 'center',
  },
  text: {
    fontSize: 18,
    color: 'white',
  },
});


export default Post;
